function openModal(){
    document.getElementById("modal").style.display ="block"
}

function closeModal(){
    document.getElementById("modal").style.display="none"
}

function openModal2(){
    document.getElementById("modal2").style.display ="block"
}

function closeModal2(){
    document.getElementById("modal2").style.display ="none"
}