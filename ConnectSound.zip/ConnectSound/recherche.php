<?php
session_start();




require_once ('configPDO.php');


/*$bdd = new PDO('mysql:host=127.0.0.1;dbname=connectsound; charset=utf8' ,'root','');
/*$bdd = new PDO('mysql:host=0y34u.myd.infomaniak.com ;dbname=0y34u_connectsound; charset=utf8' ,'0y34u_temp_1','jhtbvoRZ1nKg');
*/




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="css/style_header.css">
    <link rel="stylesheet" href="css/style_typo.css">
    <link rel="stylesheet" href="css/style_recherche.css">
</head>
<body>
<header>

    <div class="find">
        <a href="recherche.php">Recherchez de nouveaux collaborateurs !</a>
        <img src="img/loupeblanche.png">
    </div>

    <h1><img src="img/logo.png" alt="logo connectsound">Connect<span>Sound.</span></h1>

    <div class="menu">
        <ul>
            <li><img src="img/accueil.png" alt="accueil pictogramme"><a href="accueil.php?id_profile_Profiles=<?php echo $_SESSION['id_profile_Profiles']?>">Accueil</a></li>
            <li><img src="img/profil.png" alt="profil pictrogramme"><a href="profil.php?id_profile_Profiles=<?php echo $_SESSION['id_profile_Profiles']?>">Profil</a></li>
            <li><img src="img/handshake.png" alt="handshake pictogramme"><a href="collaborateurs.php?id_profile_Profiles=<?php echo $_SESSION['id_profile_Profiles']?>">Collaborateurs</a></li>
        </ul>
    </div>

</header>

<div class="content">

    <div class="search">
    <aside class="result">
    <?php
    $pseudo = $bdd->query('SELECT * FROM profiles ORDER BY id_profile_Profiles DESC');
    if(isset($_GET['q']) AND !empty($_GET['q'])) {
        $q = htmlspecialchars($_GET['q']);
        $pseudo = $bdd->query('SELECT * FROM profiles WHERE pseudonyme_Profiles LIKE "%' . $q . '%" ORDER BY id_profile_Profiles DESC');
    }
    ?>
    <form method="GET">
        <input type="search" name="q" placeholder="Recherche..." />
        <input type="submit" value="Valider" />
    </form>
        <div class="slider">
    <?php if($pseudo->rowCount() > 0) { ?>
        <ul>
            <?php while($a = $pseudo->fetch()) { ?>
                <li>
                    <a href="profil.php?id_profile_Profiles=<?php echo $a['id_profile_Profiles'] ?>"><img src="img/profile/profile_picture/<?= $a['picture_Profiles'] ?>"></a>
                    <a href="profil.php?id_profile_Profiles=<?php echo $a['id_profile_Profiles'] ?>"><?= $a['pseudonyme_Profiles'] ?></a>



                </li>
            <?php } ?>
        </ul>
        </div>

    <?php } else { ?>
            <div class="noresult">
        Aucun résultat pour: <?= $q ?>...
            </div>
    <?php } ?>

    </aside>

    <aside class="filter">

        <h2>Filtrer votre recherche</h2>
        <select name="musical_filter" id="musical_filter">
            <option value="">Choisir un genre musical</option>
            <option value="Rock">Rock</option>
            <option value="Pop">Pop</option>
            <option value="Rap">Rap</option>
        </select>
        <br>
        <select name="instru_filter" id="instru_filter">
            <option value="">Insrument</option>
            <option value="Guitare">Guitare</option>
            <option value="Basse">Basse</option>
            <option value="Batterie">Batterie</option>
        </select>

    </aside>

    </div>


    <main class="fil">


        <?php
        $articles = $bdd->query('SELECT * FROM articles ORDER BY date_time_publication DESC LIMIT 0,25');
        while ($a = $articles->fetch()) { ?>
            <div class="publication">
                <img src="img/profile/profile_picture/<?php echo $a['id_publisher'];?>" alt="">
                <div class="profile_information">
                    <h2>

                        <?php
                        $publisher = $a['id_publisher'];
                        $profilpublish = $bdd->query("SELECT pseudonyme_Profiles FROM profiles WHERE id_profile_Profiles ='$publisher'");
                        $name = $profilpublish->fetch();
                        echo $name[0];
                        ?>

                    </h2>
                    <p>Chanteur / Guitariste</p>
                    <p><?= $a['date_time_publication']?></p>
                </div>
                <hr>
                <p><?= $a['contenu'] ?></p>
                <div class="img_publication">
                    <img id="img_publi" src="img/publication/img_publication/<?php echo $a['img_article'];?>">
                </div>
                <a href="#"><?= $a['link'] ?></a>
                <hr>


                <div id="react">
                    <img src="img/publication/like.png" alt="">
                    <img src="img/publication/partager.png" alt="">
                    <img src="img/publication/enregistrer.png" alt="">
                </div>

            </div>
            <?php
        }
        ?>



</div>

</body>
</html>

