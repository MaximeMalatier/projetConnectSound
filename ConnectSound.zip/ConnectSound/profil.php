<?php
session_start();

require_once ('configPDO.php');;
/*$bdd = new PDO('mysql:host=127.0.0.1;dbname=connectsound; charset=utf8' ,'root','');
/*$bdd = new PDO('mysql:host=0y34u.myd.infomaniak.com ;dbname=0y34u_connectsound; charset=utf8' ,'0y34u_temp_1','jhtbvoRZ1nKg');*/


if (isset($_GET['id_profile_Profiles']) AND $_GET['id_profile_Profiles'] > 0)
{

    $getid = intval($_GET['id_profile_Profiles']);
    $requser = $bdd->prepare('SELECT * FROM profiles WHERE id_profile_Profiles= ?');
    $requser->execute(array($getid));
    $userinfo = $requser->fetch();


    $articles = $bdd->query('SELECT * FROM articles ORDER BY date_time_publication DESC LIMIT 0,25');


    ?>

<html>
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <link rel="stylesheet" href="css/style_header.css">
    <link rel="stylesheet" href="css/style_typo.css">
    <link rel="stylesheet" href="css/style_profile.css">
    <link rel="stylesheet" href="css/style_index.css">
    <script src="js/popup.js"></script>

</head>
<body cz-shortcut-listen="true">

<header>


    <!-- RECHERCHE -->
    <div class="find">
        <a href="recherche.php">Recherchez de nouveaux collaborateurs !</a>
        <img src="img/loupeblanche.png">
    </div>

    <h1><img src="img/logo.png" alt="logo connectsound">Connect<span>Sound.</span></h1>


    <div class="menu">
    <ul>
        <li><img src="img/accueil.png" alt="accueil pictogramme"><a href="accueil.php?id_profile_Profiles=<?php echo $_SESSION['id_profile_Profiles']?>">Accueil</a></li>
        <li><img src="img/profil.png" alt="profil pictrogramme"><a href="profil.php?id_profile_Profiles=<?php echo $_SESSION['id_profile_Profiles']?>">Profil</a></li>
        <li><img src="img/handshake.png" alt="handshake pictogramme"><a href="collaborateurs.php?id_profile_Profiles=<?php echo $_SESSION['id_profile_Profiles']?>">Collaborateurs</a></li>
    </ul>
    </div>

</header>



    <!--PROFIL TOOLS -->

    <?php
    if (isset($_SESSION['id_profile_Profiles']) AND $userinfo['id_profile_Profiles'] ==$_SESSION['id_profile_Profiles']){
    ?>
    <div class="nav_profile" >
        <ul>
            <li><img src="img/profile/my_profile/followers.png" alt="picto suivis"><a href="">Suivis</a></li>
            <div id="button_modal" onclick="openModal()"><li><img src="img/profile/my_profile/plus.png" alt="picto plus" ><p>Publier</p></li></div>
            <li><img src="img/profile/my_profile/telecharger.png" alt="picto telecharger"><a href="">Enregistrement</a></li>
        </ul>
    </div>
        <?php
    }
    ?>

    <!-- EDIT PUBLICATION -->
    <?php

    if(isset($_POST['article_link'], $_POST['article_contenu'], $_FILES['file'])) {
        if (!empty($_POST['article_link']) and !empty($_POST['article_contenu'])) {
            $tmpName = $_FILES['file']['tmp_name'];
            $name = $_FILES['file']['name'];
            $size = $_FILES['file']['size'];
            $error = $_FILES['file']['error'];

            $tabExtension = explode('.', $name);
            $extension = strtolower(end($tabExtension));

            $extensions = ['jpg', 'png', 'jpeg', 'gif'];

            $maxSize = 2097152;

            $article_link = htmlspecialchars($_POST['article_link']);
            $article_contenu = htmlspecialchars($_POST['article_contenu']);

            if (in_array($extension, $extensions) && $size <= $maxSize && $error == 0) {

                $uniqueName = uniqid('', true);

                $file = $uniqueName . "." . $extension;

                move_uploaded_file($tmpName, 'img/publication/img_publication/' . $file);

                $ins = $bdd->prepare('INSERT INTO articles (id_publisher, link, contenu, date_time_publication, img_article) VALUES (?, ?, ?, NOW(), ?)');
                $ins->execute(array($_SESSION['id_profile_Profiles'], $article_link, $article_contenu, $file));
                $message = 'Votre article a bien été posté';
            } else {
                echo "Il y a eu une erreur";
            }
        }
    }

    ?>
    <div class="overlay" id ="modal">
        <div class="redaction">
            <button id="btn_close" onclick="closeModal()"><img src="img/cross.png" alt="icone de croix"></button>
            <?php
            if (!empty($userinfo['picture_Profiles']))
            {
                ?>
                <img id="img_edit" src="img/profile/profile_picture/<?php echo $userinfo['picture_Profiles']; ?>" alt="" width="150"/>
                <?php
            }
            ?>


            <h2> <?php echo $userinfo['pseudonyme_Profiles']; ?></h2>
            <form method="POST" enctype= "multipart/form-data">

                <textarea name="article_contenu" placeholder="Description"></textarea><br />

                <input type="text" name="article_link" placeholder="Votre URL" id="link"/><br />

                <label for="file" class="label-file">Choisissez une image pour votre publication<i class="fas fa-upload"></i></label>
                <input type="file" name="file" value="Choisir une image pour votre publication" id="file">

                <input type="submit" value="Envoyer l'article" id="submit"/>
            </form>

            <br />

        </div>
    </div>


    <!-- EDIT PROFIL -->
<?php
if (isset($_SESSION['id_profile_Profiles']))
{
$requser = $bdd->prepare("SELECT * FROM profiles WHERE id_profile_Profiles=?");
$requser-> execute(array($_SESSION['id_profile_Profiles']));
$user = $requser->fetch();

if (isset($_POST['newpseudo']) AND !empty($_POST['newpseudo'] AND $_POST['newpseudo'] != $user['pseudonyme_Profiles']))
{

    $newpseudo = htmlspecialchars($_POST['newpseudo']);
    $insertpseudo = $bdd->prepare("UPDATE profiles SET pseudonyme_Profiles =? WHERE id_profile_Profiles=? ");
    $insertpseudo->execute(array($newpseudo, $_SESSION['id_profile_Profiles']));
    header('Location: profil.php?id='.$_SESSION['id_profile_Profiles']);
}

if (isset($_POST['newmail']) AND !empty($_POST['newmail'] AND $_POST['newmail'] != $user['mail_Profiles']))
{
    $newmail = htmlspecialchars($_POST['newmail']);
    $insertmail = $bdd->prepare("UPDATE profiles SET mail_Profiles =? WHERE id_profile_Profiles=? ");
    $insertmail->execute(array($newmail, $_SESSION['id_profile_Profiles']));
    header('Location: profil.php?id='.$_SESSION['id_profile_Profiles']);
}

if (isset($_POST['newmdp1']) AND !empty($_POST['newmdp1']) AND isset($_POST['newmdp2']) AND !empty($_POST['newmdp2']))
{
    $mdp1 = sha1($_POST['newmdp1']);
    $mdp2 = sha1($_POST['newmdp2']);

    if ($mdp1 == $mdp2)
    {
        $insertmdp = $bdd->prepare("UPDATE profiles SET password_Profiles = ? WHERE id_profile_Profiles=?");
        $insertmdp->execute(array($mdp1, $_SESSION['id_profile_Profiles']));

        header('Location: profil.php?id_profile_Profiles='.$_SESSION['id_profile_Profiles']);
    }
    else
    {
        $msg = "Vos deux mots de passe ne correspondent pas!";
    }
}

if (isset($_POST['biography']) AND !empty($_POST['biography'])){
    $biography = htmlspecialchars($_POST['biography']);
    $insertbio= $bdd->prepare("UPDATE profiles SET biography_Profiles= ? WHERE id_profile_Profiles= ?");
    $insertbio->execute(array($biography, $_SESSION['id_profile_Profiles']));

}

if (isset($_FILES['photo_profil']) AND !empty($_FILES['photo_profil']['name']))
{
    $taillemax = 2097152;
    $extensionsValides = array('jpg', 'jpeg', 'gif', 'png');
    if ($_FILES['photo_profil']['size'] <= $taillemax)
    {
        $extensionsUpload = strtolower(substr(strrchr($_FILES['photo_profil']['name'], '.'), 1));
        if (in_array($extensionsUpload, $extensionsValides))
        {
            $chemin = "img/profile/profile_picture/".$_SESSION['id_profile_Profiles'].".".$extensionsUpload;
            $resultat = move_uploaded_file($_FILES['photo_profil']['tmp_name'], $chemin);
            if ($resultat)
            {
                $updatePicture = $bdd->prepare("UPDATE profiles SET picture_Profiles = :picture_Profiles WHERE id_profile_Profiles = :id_profile_Profiles ");
                $updatePicture->execute(array(
                    'id_profile_Profiles' => $_SESSION['id_profile_Profiles'],
                    'picture_Profiles' => $_SESSION['id_profile_Profiles'].".".$extensionsUpload

                ));
                header('Location: profil.php?id_profile_Profiles='.$_SESSION['id_profile_Profiles']);
            }
            else
            {
                $msg = "Erreur durant l'importation de votre photo";
            }
        }
        else
        {
            $msg = "La photo doit être au format jpg, jpeg, gif ou png.";
        }
    }
    else
    {
        $msg = "Votre photo de profil est trop grande !";
    }
}
?>

    <div class="overlay2" id="modal2">
        <div class="edit_profil">

            <button id="btn_close2" onclick="closeModal2()"><img src="img/cross.png" alt="icone de croix"></button>
            <form method="POST" action="" enctype="multipart/form-data">

                <input type="text" name="newpseudo" placeholder="Pseudo" value="<?php echo $user['pseudonyme_Profiles']; ?>"/>
                <br/>


                <input type="email" name="newmail" placeholder="Mail" value="<?php echo $user['mail_Profiles']; ?>"/>
                <br/>


                <input type="password" name="newmdp1" placeholder="Mot de passe" "/>
                <br/>


                <input type="password" name="newmdp2" placeholder="Confirmation du mot de passe" "/>
                <br/>

                <textarea type="text" name="biography" id="biography"><?php echo $user['biography_Profiles']?>
                </textarea>

                <br/>
                <label>Photo de profil :</label>
                <input type="file" name="photo_profil"/>

                <input id='bouton' type="submit" value="Mettre à jour mon profil !">


            </form>
        </div>
    </div>
        <?php
        }
        else
        {
            header("Location: connexion.php");
        }
        ?>
    <!-- LE PROFIL -->
    <div class="profile">

        <div class="info_profile">
            <h2>Informations</h2>


            <h3>Je suis </h3>
            <ul>
                <li>Beatmaker</li>
                <li>Guitariste</li>
                <li>Bassiste</li>
            </ul>

            <h3>J'aime</h3>
            <ul>
                <li>Rap</li>
                <li>Rock</li>
                <li>Pop</li>
            </ul>

            <h3>Retrouvez moi sur :</h3>
            <ul id="rs">
                <li><a href=""><img src="img/profile/exemple_rs_profile/spotify.png" alt=""></a></li>
                <li><a href=""><img src="img/profile/exemple_rs_profile/deezer-logo.png" alt=""></a></li>
                <li><a href=""><img src="img/profile/exemple_rs_profile/soundcloud.png" alt=""></a></li>
            </ul>
        </div>


            <?php
            if (!empty($userinfo['picture_Profiles']))
            {
                ?>
                <img id="profile-pic" src="img/profile/profile_picture/<?php echo $userinfo['picture_Profiles']; ?>" alt="" width="150"/>
                <?php
            }
            ?>



        <div class="info_profile2">
            <h2><?php echo $userinfo['pseudonyme_Profiles']; ?></h2>


            <h3>Biographie</h3>

            <div class="bio">
                <p><?php echo $user['biography_Profiles']?></p>
            </div>



            <?php
            if (isset($_SESSION['id_profile_Profiles']) AND $userinfo['id_profile_Profiles'] ==$_SESSION['id_profile_Profiles']){
            ?>

                    <div class="tools">

                        <div id="btn" onclick="openModal2()">
                        <p>Modifier votre profil</p>
                        </div>

                        <div id="btn">
                        <a href="deconnexion.php">Se déconnecter</a>
                        </div>
                    </div>
            <?php
            }
            ?>
        </div>
    </div>



<div class="content">
<!-- Profil Suggest -->


    <aside class="suggest">


        <h2>Vous aimerez ces profils</h2>
        <hr>

        <?php
        $recupUser = $bdd ->query('SELECT * FROM profiles');
        while ($userinfo = $recupUser ->fetch()){
            ?>

            <div class="profile_suggest">
                <?php
                if (!empty($userinfo['picture_Profiles']))
                {
                    ?>
                    <img src="img/profile/profile_picture/<?php echo $userinfo['picture_Profiles']; ?>" alt="" width="150"/>
                    <?php
                }
                ?>
                <div class="profile_information">
                    <h3><?php echo $userinfo['pseudonyme_Profiles']; ?></h3>


                <div class="bouton">
                    <a href="profil.php?id_profile_Profiles=<?php echo $userinfo['id_profile_Profiles'] ?>">Voir le profil</a>

                </div>
                </div>
            </div>
            <?php
        }
        ?>
    </aside>

<!-- Fil de publication -->

    <main class="fil">

        <?php while ($a = $articles->fetch()) { ?>
            <div class="publication">
                <img src="img/profile/profile_picture/<?php echo $a['id_publisher'];?>" alt="">
                <div class="profile_information">
                    <h2>

                        <?php
                        $publisher = $a['id_publisher'];
                        $profilpublish = $bdd->query("SELECT pseudonyme_Profiles FROM profiles WHERE id_profile_Profiles ='$publisher'");
                        $name = $profilpublish->fetch();
                        echo $name[0];



                        ?>

                    </h2>
                    <p>Chanteur / Guitariste</p>
                    <p><?= $a['date_time_publication']?></p>
                </div>
                <hr>
                <p><?= $a['contenu'] ?></p>
                <div class="img_publication">
                    <img id="img_publi" src="img/publication/img_publication/<?php echo $a['img_article'];?>" </p>
                </div>
                <a href="#"><?= $a['link'] ?></a>
                <hr>


                <div id="react">
                    <img src="img/publication/like.png" alt="">
                    <img src="img/publication/partager.png" alt="">
                    <img src="img/publication/enregistrer.png" alt="">
                </div>

            </div>
            <?php
        }
        ?>
    </main>

<!-- Espace Collaborateurs -->

        <aside class="collaborateurs">


            <h2 id="title_collab">Collaborateurs</h2>

            <?php
            $recupUser = $bdd ->query('SELECT * FROM profiles');
            while ($userinfo = $recupUser ->fetch()){
                ?>
                <div class="collab">

                    <?php
                    if (!empty($userinfo['picture_Profiles']))
                    {
                        ?>
                        <img id="profile-img" src="img/profile/profile_picture/<?php echo $userinfo['picture_Profiles']; ?>" alt="" width="150"/>
                        <?php
                    }
                    ?>
                    <h2><a href="collaborateurs.php?id_profile_Profiles=<?php echo $userinfo['id_profile_Profiles'] ?>"><?php echo $userinfo['pseudonyme_Profiles']; ?></a></h2>


                </div>

                <?php
            }
            ?>
        </aside>
</div>


</body>



</html>
<?php
}
?>
