<?php




$bdd = new PDO('mysql:host=0y34u.myd.infomaniak.com;dbname=0y34u_bdd; charset=utf8' ,'0y34u_bdd','Bdd170902',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));

?>